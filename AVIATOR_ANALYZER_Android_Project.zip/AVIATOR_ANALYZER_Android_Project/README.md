# Aviator Analyzer — protótipo Android

Este é um projeto-fonte inicial, não um APK pronto.

## O que inclui
- Registro manual de multiplicadores.
- Resumo descritivo das últimas 5, 10, 15 e 60 entradas.
- Simulador local de saldo com valores fictícios.
- Sem login, conexão ou alteração de contas reais.

## Gerar APK
Abra o projeto no Android Studio em um computador com Android SDK instalado e use Build > Build Bundle(s) / APK(s) > Build APK(s).

O projeto ainda precisa ser compilado e testado. Não há garantia de instalação até a compilação ser concluída.
