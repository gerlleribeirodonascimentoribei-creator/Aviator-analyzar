package com.example.aviatoranalyzer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AnalyzerScreen() }
    }
}

@Composable
fun AnalyzerScreen() {
    var entry by remember { mutableStateOf("") }
    var values by remember { mutableStateOf(listOf<Double>()) }
    var deposit by remember { mutableStateOf("50") }
    var simulatedBalance by remember { mutableStateOf(0.0) }
    MaterialTheme {
        Scaffold { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item { Text("AVIATOR ANALYZER", style = MaterialTheme.typography.headlineMedium) }
                item { Text("Análise descritiva de resultados registrados. Não prevê rodadas futuras.") }
                item {
                    OutlinedTextField(entry, { entry = it }, label = { Text("Multiplicador (ex.: 2.45)") }, modifier = Modifier.fillMaxWidth())
                    Button(onClick = {
                        entry.replace(",", ".").toDoubleOrNull()?.takeIf { it > 0 }?.let { values = values + it; entry = "" }
                    }) { Text("Adicionar resultado") }
                }
                item { Text("Histórico: ${values.size} resultados") }
                item {
                    val last = values.takeLast(60)
                    Text("Últimos 5: ${summary(values.takeLast(5))}")
                    Text("Últimos 10: ${summary(values.takeLast(10))}")
                    Text("Últimos 15: ${summary(values.takeLast(15))}")
                    Text("Últimos 60: ${summary(last)}")
                }
                item { Text("Simulador fictício de depósitos", style = MaterialTheme.typography.titleMedium) }
                item {
                    OutlinedTextField(deposit, { deposit = it }, label = { Text("Valor fictício em R$") })
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(onClick = { deposit.toDoubleOrNull()?.takeIf { it > 0 }?.let { simulatedBalance += it } }) { Text("Simular crédito") }
                        OutlinedButton(onClick = { simulatedBalance = 0.0 }) { Text("Zerar") }
                    }
                    Text("Saldo simulado: R$ ${"%.2f".format(simulatedBalance)}")
                }
                item { Text("Observação: os dados são locais e fictícios. Não conecte contas reais nem use para tentar prever resultados.") }
                items(values.asReversed()) { v -> Text("${"%.2f".format(v)}x") }
            }
        }
    }
}

private fun summary(list: List<Double>): String {
    if (list.isEmpty()) return "sem dados"
    val sorted = list.sorted()
    val median = if (sorted.size % 2 == 1) sorted[sorted.size / 2] else (sorted[sorted.size/2-1] + sorted[sorted.size/2]) / 2
    val low = list.count { it < 2 }
    val mid = list.count { it >= 2 && it < 5 }
    val high = list.count { it >= 5 && it < 10 }
    val x10 = list.count { it >= 10 }
    return "n=${list.size}, mediana=${"%.2f".format(median)}x; <2x=$low, 2–4.99x=$mid, 5–9.99x=$high, ≥10x=$x10"
}
